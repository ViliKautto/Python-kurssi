print ("Moro maailma!", eioo)
