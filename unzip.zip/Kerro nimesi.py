def main():
    nimi = input("Kerro nimesi: ")
    print("Hei", nimi )
    print ("hyvin sujuu koodaileminen!")
main()