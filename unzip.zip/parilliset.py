def main():
    i = 0
    for i in range(0,101,2):
        print(i)
    for i in range(0,101,2):
        print(100-i)
main()