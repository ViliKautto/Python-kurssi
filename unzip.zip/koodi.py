def main():
    päälle = "e0f"
    pois = "e00"
    odota = "w0040"
    kehäledit = ["s05","s06","s07","s08","s09","s1a","s2b","s3c","s4c","s5c","s6c","s7c","s8b","s9a","sa9","sa8","sa7","sa6","sa5","s94","s83","s72","s62","s52","s42","s32","s23","s14"]
    kuusikymmentä = "s36s35s34s44s54s64s74s75s76s66s56s55"
    viisikymmentä = "s36s35s34s44s54s55s56s66s76s75s74"
    neljäkymmentä =  "s34s44s54s55s56s46s36s66s76"
    kolmekymmentä = "s34s35s36s46s56s55s54s66s76s75s74"
    kaksikymmentä = "s34s35s36s46s56s55s54s64s74s75s76"
    kymmenen = "s36s46s56s66s76"
    ei_kymmeniä = "s36s35s34s44s54s64s74s75s76s66s56s46"
    yhdeksän = "s78s79s7as6as5as4as3as39s38s48s58s59"
    kahdeksan = "s38s39s3as4as5as6as7as79s78s68s58s48s59"
    seitsemän = "s38s39s3as4as5as6as7a"
    kuusi = "s3as39s38s48s58s68s78s79s7as6as5as59"
    viisi = "s3as39s38s48s58s59s5as6as7as79s78"
    neljä = "s38s48s58s59s5as4as3as6as7a"
    kolme = "s38s39s3as4as5as59s58s6as7as79s78"
    kaksi = "s38s39s3as4as5as59s58s68s78s79s7a"
    yksi = "s3as4as5as6as7a"
    nolla = "s38s39s3as4as5as6as7as79s78s68s58s48"
    print(päälle, kuusikymmentä, nolla, kehäledit[0],odota, pois,kuusikymmentä, nolla, kehäledit[0], sep="" )
    print(päälle, viisikymmentä, yhdeksän, kehäledit[1], odota, pois, viisikymmentä, yhdeksän, kehäledit[1], sep="")
    print(päälle, viisikymmentä, kahdeksan, kehäledit[2], odota, pois, viisikymmentä, kahdeksan, kehäledit[2], sep="")
    print(päälle, viisikymmentä, seitsemän, kehäledit[3], odota, pois,viisikymmentä,seitsemän, kehäledit[3], sep="")
    print(päälle, viisikymmentä, kuusi, kehäledit[4], odota, pois, viisikymmentä, kuusi, kehäledit[4], sep="")
    print(päälle, viisikymmentä, viisi, kehäledit[5],odota,pois,viisikymmentä,viisi ,kehäledit[5], sep="")
    print(päälle, viisikymmentä, neljä, kehäledit[6],odota,pois,viisikymmentä,neljä ,kehäledit[6], sep="")
    print(päälle, viisikymmentä,kolme , kehäledit[7],odota,pois,viisikymmentä,kolme ,kehäledit[7], sep="")
    print(päälle, viisikymmentä, kaksi, kehäledit[8],odota,pois,viisikymmentä,kaksi ,kehäledit[8], sep="")
    print(päälle, viisikymmentä,yksi , kehäledit[9],odota,pois,viisikymmentä,yksi ,kehäledit[9], sep="")
    print(päälle, viisikymmentä, nolla, kehäledit[10],odota,pois,viisikymmentä,nolla ,kehäledit[10], sep="")
    print(päälle, neljäkymmentä,yhdeksän , kehäledit[11],odota,pois,neljäkymmentä,yhdeksän ,kehäledit[11], sep="")
    print(päälle, neljäkymmentä, kahdeksan, kehäledit[12],odota,pois,neljäkymmentä,kahdeksan ,kehäledit[12], sep="")
    print(päälle, neljäkymmentä, seitsemän, kehäledit[13],odota,pois,neljäkymmentä,seitsemän ,kehäledit[13], sep="")
    print(päälle, neljäkymmentä, kuusi, kehäledit[14],odota,pois,neljäkymmentä,kuusi ,kehäledit[14], sep="")
    print(päälle, neljäkymmentä, viisi , kehäledit[15],odota,pois,neljäkymmentä,viisi ,kehäledit[15], sep="")
    print(päälle, neljäkymmentä, neljä, kehäledit[16],odota,pois,neljäkymmentä,neljä ,kehäledit[16], sep="")
    print(päälle, neljäkymmentä, kolme , kehäledit[17],odota,pois,neljäkymmentä,kolme ,kehäledit[17], sep="")
    print(päälle, neljäkymmentä,kaksi , kehäledit[18],odota,pois,neljäkymmentä,kaksi ,kehäledit[18], sep="")
    print(päälle, neljäkymmentä,yksi , kehäledit[19],odota,pois,neljäkymmentä,yksi ,kehäledit[19], sep="")
    print(päälle, neljäkymmentä,nolla , kehäledit[20],odota,pois,neljäkymmentä,nolla ,kehäledit[20], sep="")
    print(päälle, kolmekymmentä, yhdeksän , kehäledit[21],odota,pois,kolmekymmentä, yhdeksän,kehäledit[21], sep="")
    print(päälle, kolmekymmentä,kahdeksan , kehäledit[22],odota,pois,kolmekymmentä, kahdeksan ,kehäledit[22], sep="")
    print(päälle, kolmekymmentä, seitsemän, kehäledit[23],odota,pois,kolmekymmentä,seitsemän ,kehäledit[23], sep="")
    print(päälle, kolmekymmentä,kuusi , kehäledit[24],odota,pois,kolmekymmentä, kuusi ,kehäledit[24], sep="")
    print(päälle, kolmekymmentä,viisi, kehäledit[25],odota,pois,kolmekymmentä,viisi ,kehäledit[25], sep="")
    print(päälle, kolmekymmentä, neljä, kehäledit[26],odota,pois,kolmekymmentä,neljä ,kehäledit[26], sep="")
    print(päälle, kolmekymmentä, kolme , kehäledit[27],odota,pois,kolmekymmentä, kolme,kehäledit[27], sep="")
    print(päälle, kolmekymmentä,kaksi , kehäledit[0],odota,pois,kolmekymmentä,kaksi ,kehäledit[0], sep="")
    print(päälle, kolmekymmentä, yksi , kehäledit[1],odota,pois,kolmekymmentä,yksi ,kehäledit[1], sep="")
    print(päälle, kolmekymmentä,nolla , kehäledit[2],odota,pois,kolmekymmentä,nolla,kehäledit[2], sep="")
    print(päälle, kaksikymmentä, yhdeksän , kehäledit[3],odota,pois,kaksikymmentä, yhdeksän ,kehäledit[3], sep="")
    print(päälle, kaksikymmentä, kahdeksan, kehäledit[4],odota,pois,kaksikymmentä,kahdeksan ,kehäledit[4], sep="")
    print(päälle, kaksikymmentä,seitsemän , kehäledit[5],odota,pois,kaksikymmentä,seitsemän ,kehäledit[5], sep="")
    print(päälle, kaksikymmentä,kuusi , kehäledit[6],odota,pois,kaksikymmentä,kuusi ,kehäledit[6], sep="")
    print(päälle, kaksikymmentä, viisi , kehäledit[7],odota,pois,kaksikymmentä,viisi,kehäledit[7], sep="")
    print(päälle, kaksikymmentä, neljä , kehäledit[8],odota,pois,kaksikymmentä, neljä ,kehäledit[8], sep="")
    print(päälle, kaksikymmentä, kolme, kehäledit[9],odota,pois,kaksikymmentä, kolme ,kehäledit[9], sep="")
    print(päälle, kaksikymmentä, kaksi, kehäledit[10],odota,pois,kaksikymmentä,kaksi ,kehäledit[10], sep="")
    print(päälle, kaksikymmentä, yksi , kehäledit[11],odota,pois,kaksikymmentä,yksi ,kehäledit[11], sep="")
    print(päälle, kaksikymmentä, nolla, kehäledit[12],odota,pois,kaksikymmentä, nolla ,kehäledit[12], sep="")
    print(päälle, kymmenen, yhdeksän , kehäledit[13],odota,pois,kymmenen,yhdeksän ,kehäledit[13], sep="")
    print(päälle, kymmenen,kahdeksan , kehäledit[14],odota,pois,kymmenen, kahdeksan,kehäledit[14], sep="")
    print(päälle, kymmenen,seitsemän , kehäledit[15],odota,pois,kymmenen,seitsemän ,kehäledit[15], sep="")
    print(päälle, kymmenen,kuusi , kehäledit[16],odota,pois,kymmenen,kuusi ,kehäledit[16], sep="")
    print(päälle, kymmenen,viisi , kehäledit[17],odota,pois,kymmenen,viisi ,kehäledit[17], sep="")
    print(päälle, kymmenen,neljä , kehäledit[18],odota,pois,kymmenen,neljä ,kehäledit[18], sep="")
    print(päälle, kymmenen,kolme , kehäledit[19],odota,pois,kymmenen,kolme ,kehäledit[19], sep="")
    print(päälle, kymmenen, kaksi , kehäledit[20],odota,pois,kymmenen,kaksi ,kehäledit[20], sep="")
    print(päälle, kymmenen,yksi , kehäledit[21],odota,pois,kymmenen,yksi ,kehäledit[21], sep="")
    print(päälle, kymmenen, nolla, kehäledit[22],odota,pois,kymmenen,nolla ,kehäledit[22], sep="")
    print(päälle, ei_kymmeniä, yhdeksän, kehäledit[23],odota,pois,ei_kymmeniä, yhdeksän ,kehäledit[23], sep="")
    print(päälle, ei_kymmeniä,kahdeksan , kehäledit[24],odota,pois,ei_kymmeniä,kahdeksan ,kehäledit[24], sep="")
    print(päälle, ei_kymmeniä, seitsemän, kehäledit[25],odota,pois,ei_kymmeniä,seitsemän ,kehäledit[25], sep="")
    print(päälle, ei_kymmeniä, kuusi, kehäledit[26],odota,pois,ei_kymmeniä,kuusi ,kehäledit[26], sep="")
    print(päälle, ei_kymmeniä,viisi , kehäledit[27],odota,pois,ei_kymmeniä, viisi,kehäledit[27], sep="")
    print(päälle, ei_kymmeniä, neljä, kehäledit[0],odota,pois,ei_kymmeniä,neljä ,kehäledit[0], sep="")
    print(päälle, ei_kymmeniä,kolme , kehäledit[1],odota,pois,ei_kymmeniä,kolme ,kehäledit[1], sep="")
    print(päälle, ei_kymmeniä, kaksi , kehäledit[2],odota,pois,ei_kymmeniä,kaksi ,kehäledit[2], sep="")
    print(päälle, ei_kymmeniä,yksi , kehäledit[3],odota,pois,ei_kymmeniä,yksi ,kehäledit[3], sep="")
    print(päälle, ei_kymmeniä,nolla , kehäledit[4],odota,pois,ei_kymmeniä,nolla ,kehäledit[4], sep="")













main()