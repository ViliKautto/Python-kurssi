x = a
x.find

def osamäärä(a,b):
    """

    :param a: jaettava
    :param b: jakaja
    :return c: osamäärän arvo
    """
    c = a/b
    return c
osamäärä