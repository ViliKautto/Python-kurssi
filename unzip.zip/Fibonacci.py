def main():
    rivi = input("Kuinka monta Fibonaccin lukua haluat: ")
    LKM = int(rivi)
    a = 0
    b = 1
    i = 2
    if LKM == 1:
        print ("1. 1")
    else:
        print("1. 1")
        print("2. 1")
    while i < LKM:
        a = a + b
        i = i + 1
        print(i,".", " ",a+b, sep="")
        if i == LKM:
            return
        else:
            b = b + a
            i = i + 1
            print(i,"."," ",a+b, sep="")
main()