def main():
    nimi = input("Kerro nimesi: ")
    print("Hei ", nimi, ", hyvin sujuu tulosteen muotoileminen!", sep=(""))
main()
