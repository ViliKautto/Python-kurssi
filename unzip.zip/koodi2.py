def main():
    päälle = "e0f"
    pois = "e00"
    odota = "w0040"
    kehäledit = ["s05","s06","s07","s08","s09","s1a","s2b","s3c","s4c","s5c","s6c","s7c","s8b","s9a","sa9","sa8","sa7","sa6","sa5","s94","s83","s72","s62","s52","s42","s32","s23","s14"]
    kuusikymmentä = "s36s35s34s44s54s64s74s75s76s66s56s55"
    viisikymmentä = "s36s35s34s44s54s55s56s66s76s75s74"
    neljäkymmentä =  "s34s44s54s55s56s46s36s66s76"
    kolmekymmentä = "s34s35s36s46s56s55s54s66s76s75s74"
    kaksikymmentä = "s34s35s36s46s56s55s54s64s74s75s76"
    kymmenen = "s36s46s56s66s76"
    ei_kymmeniä = "s36s35s34s44s54s64s74s75s76s66s56s46"
    yhdeksän = "s78s79s7as6as5as4as3as39s38s48s58s59"
    kahdeksan = "s38s39s3as4as5as6as7as79s78s68s58s48s59"
    seitsemän = "s38s39s3as4as5as6as7a"
    kuusi = "s3as39s38s48s58s68s78s79s7as6as5as59"
    viisi = "s3as39s38s48s58s59s5as6as7as79s78"
    neljä = "s38s48s58s59s5as4as3as6as7a"
    kolme = "s38s39s3as4as5as59s58s6as7as79s78"
    kaksi = "s38s39s3as4as5as59s58s68s78s79s7a"
    yksi = "s3as4as5as6as7a"
    nolla = "s38s39s3as4as5as6as7as79s78s68s58s48"
    alaledi1 = "sc4"
    alaledi2 = "sc6"
    alaledi3 = "sc8"
    alaledi4 = "sca"
    a = "a"
    print(päälle, kuusikymmentä,alaledi1, alaledi2, alaledi3,alaledi4, nolla, kehäledit[0],odota, pois,a, sep="" )
    print(päälle, viisikymmentä, yhdeksän, kehäledit[1], odota, pois, a, sep="")
    print(päälle, viisikymmentä, kahdeksan, kehäledit[2], odota, pois, a, sep="")
    print(päälle, viisikymmentä, seitsemän, kehäledit[3], odota, pois,a, sep="")
    print(päälle, viisikymmentä, kuusi, kehäledit[4], odota, pois, a, sep="")
    print(päälle, viisikymmentä, viisi, kehäledit[5],odota,pois,a, sep="")
    print(päälle, viisikymmentä, neljä, kehäledit[6],odota,pois,a, sep="")
    print(päälle, viisikymmentä,kolme , kehäledit[7],odota,pois,a, sep="")
    print(päälle, viisikymmentä, kaksi, kehäledit[8],odota,pois,a, sep="")
    print(päälle, viisikymmentä,yksi , kehäledit[9],odota,pois,a, sep="")
    print(päälle, viisikymmentä, nolla, kehäledit[10],odota,pois,a, sep="")
    print(päälle, neljäkymmentä,yhdeksän , kehäledit[11],odota,pois,a, sep="")
    print(päälle, neljäkymmentä, kahdeksan, kehäledit[12],odota,pois,a, sep="")
    print(päälle, neljäkymmentä, seitsemän, kehäledit[13],odota,pois,a, sep="")
    print(päälle, neljäkymmentä, kuusi, kehäledit[14],odota,pois,a, sep="")
    print(päälle, neljäkymmentä, viisi , kehäledit[15],odota,pois,a, sep="")
    print(päälle, alaledi1, alaledi2, alaledi3, neljäkymmentä, neljä, kehäledit[16],odota,pois,a, sep="")
    print(päälle, neljäkymmentä, kolme , kehäledit[17],odota,pois,a, sep="")
    print(päälle, neljäkymmentä,kaksi , kehäledit[18],odota,pois,a, sep="")
    print(päälle, neljäkymmentä,yksi , kehäledit[19],odota,pois,a, sep="")
    print(päälle, neljäkymmentä,nolla , kehäledit[20],odota,pois,a, sep="")
    print(päälle, kolmekymmentä, yhdeksän , kehäledit[21],odota,pois,a, sep="")
    print(päälle, kolmekymmentä,kahdeksan , kehäledit[22],odota,pois,a, sep="")
    print(päälle, kolmekymmentä, seitsemän, kehäledit[23],odota,pois,a, sep="")
    print(päälle, kolmekymmentä,kuusi , kehäledit[24],odota,pois,a, sep="")
    print(päälle, kolmekymmentä,viisi, kehäledit[25],odota,pois,a, sep="")
    print(päälle, kolmekymmentä, neljä, kehäledit[26],odota,pois,a, sep="")
    print(päälle, kolmekymmentä, kolme , kehäledit[27],odota,pois,a, sep="")
    print(päälle, kolmekymmentä,kaksi , kehäledit[0],odota,pois,a, sep="")
    print(päälle, kolmekymmentä, yksi , kehäledit[1],odota,pois,a, sep="")
    print(päälle, alaledi1, alaledi2,kolmekymmentä,nolla , kehäledit[2],odota,pois,a, sep="")
    print(päälle, kaksikymmentä, yhdeksän , kehäledit[3],odota,pois,a, sep="")
    print(päälle, kaksikymmentä, kahdeksan, kehäledit[4],odota,pois,a, sep="")
    print(päälle, kaksikymmentä,seitsemän , kehäledit[5],odota,pois,a, sep="")
    print(päälle, kaksikymmentä,kuusi , kehäledit[6],odota,pois,a, sep="")
    print(päälle, kaksikymmentä, viisi , kehäledit[7],odota,pois,a, sep="")
    print(päälle, kaksikymmentä, neljä , kehäledit[8],odota,pois,a, sep="")
    print(päälle, kaksikymmentä, kolme, kehäledit[9],odota,pois,a, sep="")
    print(päälle, kaksikymmentä, kaksi, kehäledit[10],odota,pois,a, sep="")
    print(päälle, kaksikymmentä, yksi , kehäledit[11],odota,pois,a, sep="")
    print(päälle, kaksikymmentä, nolla, kehäledit[12],odota,pois,a, sep="")
    print(päälle, kymmenen, yhdeksän , kehäledit[13],odota,pois,a, sep="")
    print(päälle, kymmenen,kahdeksan , kehäledit[14],odota,pois,a, sep="")
    print(päälle, kymmenen,seitsemän , kehäledit[15],odota,pois,a, sep="")
    print(päälle, kymmenen,kuusi , kehäledit[16],odota,pois,a, sep="")
    print(päälle, alaledi1, kymmenen,viisi , kehäledit[17],odota,pois,a, sep="")
    print(päälle, kymmenen,neljä , kehäledit[18],odota,pois,a, sep="")
    print(päälle, kymmenen,kolme , kehäledit[19],odota,pois,a, sep="")
    print(päälle, kymmenen, kaksi , kehäledit[20],odota,pois,a, sep="")
    print(päälle, kymmenen,yksi , kehäledit[21],odota,pois,a, sep="")
    print(päälle, kymmenen, nolla, kehäledit[22],odota,pois,a, sep="")
    print(päälle, ei_kymmeniä, yhdeksän, kehäledit[23],odota,pois,a, sep="")
    print(päälle, ei_kymmeniä,kahdeksan , kehäledit[24],odota,pois,a, sep="")
    print(päälle, ei_kymmeniä, seitsemän, kehäledit[25],odota,pois,a, sep="")
    print(päälle, ei_kymmeniä, kuusi, kehäledit[26],odota,pois,a, sep="")
    print(päälle, ei_kymmeniä,viisi , kehäledit[27],odota,pois,a, sep="")
    print(päälle, ei_kymmeniä, neljä, kehäledit[0],odota,pois,a, sep="")
    print(päälle, ei_kymmeniä,kolme , kehäledit[1],odota,pois,a, sep="")
    print(päälle, ei_kymmeniä, kaksi , kehäledit[2],odota,pois,a, sep="")
    print(päälle, ei_kymmeniä,yksi , kehäledit[3],odota,pois,a, sep="")
    print(päälle, ei_kymmeniä,nolla , kehäledit[4],odota,pois,a, sep="")
    print("wfff")













main()