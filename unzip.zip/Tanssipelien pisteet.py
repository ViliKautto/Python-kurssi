def laske_keskiarvo(kappale_tulos):
    values = kappale_tulos.values()
    keskiarvo = sum(values) / len(kappale_tulos)
    return keskiarvo
