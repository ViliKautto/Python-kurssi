
def main():
    pii = 3.14159265358979323846
    print("Piin likiarvo on {:.0g} tai jos tarkkoja halutaan olla, niin {:.5g}".format(pii, pii))


main()
