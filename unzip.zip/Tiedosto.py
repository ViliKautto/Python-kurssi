tässä tulee hirmuinen rölli
on mulla metsässä tölli
ja siellä mä asustelen
ja sieltä mä hiippailen