def main():
    päälle = "e0f"
    pois = "e00"
    odota = "w0040"
    kehäledit = ["s05","s06","s07","s08","s09","s1a","s2b","s3c","s4c","s5c","s6c","s7c","s8b","s9a","sa9","sa8","sa7","sa6","sa5","s94","s83","s72","s62","s52","s42","s32","s23","s14"]
    kuusikymmentä = "s36s35s34s44s54s64s74s75s76s66s56s55"
    viisikymmentä = "s36s35s34s44s54s55s56s66s76s75s74"
    neljäkymmentä =  "s34s44s54s55s56s46s36s66s76"
    kolmekymmentä = "s34s35s36s46s56s55s54s66s76s75s74"
    kaksikymmentä = "s34s35s36s46s56s55s54s64s74s75s76"
    kymmenen = "s36s46s56s66s76"
    ei_kymmeniä = "s36s35s34s44s54s64s74s75s76s66s56s46"
    yhdeksän = "s78s79s7as6as5as4as3as39s38s48s58s59"
    kahdeksan = "s38s39s3as4as5as6as7as79s78s68s58s48s59"
    seitsemän = "s38s39s3as4as5as6as7a"
    kuusi = "s3as39s38s48s58s68s78s79s7as6as5as59"
    viisi = "s3as39s38s48s58s59s5as6as7as79s78"
    neljä = "s38s48s58s59s5as4as3as6as7a"
    kolme = "s38s39s3as4as5as59s58s6as7as79s78"
    kaksi = "s38s39s3as4as5as59s58s68s78s79s7a"
    yksi = "s3as4as5as6as7a"
    nolla = "s38s39s3as4as5as6as7as79a78a68s58ss48"
    print(päälle, kuusikymmentä, nolla, kehäledit[0],odota, pois,kuusikymmentä, nolla, kehäledit[0], sep="" )
    print(päälle, viisikymmentä, yhdeksän, kehäledit[1], odota, pois, yhdeksän, kehäledit[1], sep="")
    print(päälle, kahdeksan, kehäledit[2], odota, pois,  kahdeksan, kehäledit[2], sep="")
    print(päälle, seitsemän, kehäledit[3], odota, pois,seitsemän, kehäledit[3], sep="")
    print(päälle, kuusi, kehäledit[4], odota, pois,  kuusi, kehäledit[4], sep="")
    print(päälle, viisi, kehäledit[5],odota,pois,viisi ,kehäledit[5], sep="")
    print(päälle, neljä, kehäledit[6],odota,pois,neljä ,kehäledit[6], sep="")
    print(päälle, kolme , kehäledit[7],odota,pois,kolme ,kehäledit[7], sep="")
    print(päälle, kaksi, kehäledit[8],odota,pois,kaksi ,kehäledit[8], sep="")
    print(päälle, yksi , kehäledit[9],odota,pois,yksi ,kehäledit[9], sep="")
    print(päälle, nolla, kehäledit[10],odota,pois,viisikymmentä,nolla ,kehäledit[10], sep="")
    print(päälle, neljäkymmentä,yhdeksän , kehäledit[11],odota,pois,yhdeksän ,kehäledit[11], sep="")
    print(päälle, kahdeksan, kehäledit[12],odota,pois,kahdeksan ,kehäledit[12], sep="")
    print(päälle, seitsemän, kehäledit[13],odota,pois,seitsemän ,kehäledit[13], sep="")
    print(päälle, kuusi, kehäledit[14],odota,pois,kuusi ,kehäledit[14], sep="")
    print(päälle, viisi , kehäledit[15],odota,pois,viisi ,kehäledit[15], sep="")
    print(päälle, neljä, kehäledit[16],odota,pois,neljä ,kehäledit[16], sep="")
    print(päälle, kolme , kehäledit[17],odota,pois,kolme ,kehäledit[17], sep="")
    print(päälle, kaksi , kehäledit[18],odota,pois,kaksi ,kehäledit[18], sep="")
    print(päälle, yksi , kehäledit[19],odota,pois,yksi ,kehäledit[19], sep="")
    print(päälle, nolla , kehäledit[20],odota,pois,neljäkymmentä,nolla ,kehäledit[20], sep="")
    print(päälle, kolmekymmentä, yhdeksän , kehäledit[21],odota,pois, yhdeksän,kehäledit[21], sep="")
    print(päälle, kahdeksan , kehäledit[22],odota,pois, kahdeksan ,kehäledit[22], sep="")
    print(päälle, seitsemän, kehäledit[23],odota,pois,seitsemän ,kehäledit[23], sep="")
    print(päälle, kuusi , kehäledit[24],odota,pois, kuusi ,kehäledit[24], sep="")
    print(päälle, viisi, kehäledit[25],odota,pois,viisi ,kehäledit[25], sep="")
    print(päälle, neljä, kehäledit[26],odota,pois,neljä ,kehäledit[26], sep="")
    print(päälle, kolme , kehäledit[27],odota,pois, kolme,kehäledit[27], sep="")
    print(päälle, kaksi , kehäledit[0],odota,pois,kaksi ,kehäledit[0], sep="")
    print(päälle, yksi , kehäledit[1],odota,pois,yksi ,kehäledit[1], sep="")
    print(päälle, nolla,  kehäledit[2],odota,pois,kolmekymmentä,nolla,kehäledit[2], sep="")
    print(päälle, kaksikymmentä, yhdeksän , kehäledit[3],odota,pois, yhdeksän ,kehäledit[3], sep="")
    print(päälle, kahdeksan, kehäledit[4],odota,pois,kahdeksan ,kehäledit[4], sep="")
    print(päälle, seitsemän , kehäledit[5],odota,pois,seitsemän ,kehäledit[5], sep="")
    print(päälle, kuusi , kehäledit[6],odota,pois,kuusi ,kehäledit[6], sep="")
    print(päälle, viisi , kehäledit[7],odota,pois,viisi,kehäledit[7], sep="")
    print(päälle, neljä , kehäledit[8],odota,pois, neljä ,kehäledit[8], sep="")
    print(päälle, kolme, kehäledit[9],odota,pois, kolme ,kehäledit[9], sep="")
    print(päälle, kaksi, kehäledit[10],odota,pois,kaksi ,kehäledit[10], sep="")
    print(päälle, yksi , kehäledit[11],odota,pois,yksi ,kehäledit[11], sep="")
    print(päälle, nolla, kehäledit[12],odota,pois,kaksikymmentä, nolla ,kehäledit[12], sep="")
    print(päälle, kymmenen, yhdeksän , kehäledit[13],odota,pois,yhdeksän ,kehäledit[13], sep="")
    print(päälle, kahdeksan , kehäledit[14],odota,pois, kahdeksan,kehäledit[14], sep="")
    print(päälle, seitsemän , kehäledit[15],odota,pois,seitsemän ,kehäledit[15], sep="")
    print(päälle, kuusi , kehäledit[16],odota,pois,kuusi ,kehäledit[16], sep="")
    print(päälle, viisi , kehäledit[17],odota,pois,viisi ,kehäledit[17], sep="")
    print(päälle, neljä , kehäledit[18],odota,pois,neljä ,kehäledit[18], sep="")
    print(päälle, kolme , kehäledit[19],odota,pois,kolme ,kehäledit[19], sep="")
    print(päälle, kaksi , kehäledit[20],odota,pois,kaksi ,kehäledit[20], sep="")
    print(päälle, yksi , kehäledit[21],odota,pois,yksi ,kehäledit[21], sep="")
    print(päälle, nolla, kehäledit[22],odota,pois,kymmenen,nolla ,kehäledit[22], sep="")
    print(päälle, ei_kymmeniä, yhdeksän, kehäledit[23],odota,pois, yhdeksän ,kehäledit[23], sep="")
    print(päälle, kahdeksan , kehäledit[24],odota,pois,kahdeksan ,kehäledit[24], sep="")
    print(päälle, seitsemän, kehäledit[25],odota,pois,seitsemän ,kehäledit[25], sep="")
    print(päälle, kuusi, kehäledit[26],odota,pois,kuusi ,kehäledit[26], sep="")
    print(päälle, viisi , kehäledit[27],odota,pois, viisi,kehäledit[27], sep="")
    print(päälle, neljä, kehäledit[0],odota,pois,neljä ,kehäledit[0], sep="")
    print(päälle, kolme , kehäledit[1],odota,pois,kolme ,kehäledit[1], sep="")
    print(päälle, kaksi , kehäledit[2],odota,pois,kaksi ,kehäledit[2], sep="")
    print(päälle, yksi , kehäledit[3],odota,pois,yksi ,kehäledit[3], sep="")
    print(päälle, nolla , kehäledit[4],odota,pois,ei_kymmeniä,nolla ,kehäledit[4], sep="")













main()