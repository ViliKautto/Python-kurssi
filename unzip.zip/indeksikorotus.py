rivi = input ("Syötä opintotuen määrä: ")
tuki = float(rivi)
print("Indeksikorotuksen ollessa 1.17 prosenttia")
print("olisi opintotuki korotuksen jälkeen", tuki * 1.0117, "euroa")
tukii = tuki * 1.0117
print("ja jos sattuisi tulemaan vielä toinen indeksikorotus")
print("olisi opintotuki sen jä<<<lkeen jo", tukii * 1.0117, "euroa")