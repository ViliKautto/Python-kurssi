def main():
    rivi = input("Kuinka monta Fibonaccin lukua haluat: ")
    LKM = int(rivi)
    a = 0
    b = 1
    n = 3
    if LKM == 1:
        print ("1. 1")
    else:
        print("1. 1")
        print("2. 1")
    for i in range (LKM):
        if n > LKM:
            return
        else:
            a = a + b
            print(n,".", " ",a+b, sep="")
            n = n + 1
        if n > LKM:
            return
        else:
            b = b + a
            print(n,".", " ",a+b, sep="")
            n = n + 1

main()